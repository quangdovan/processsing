import requests

#     #Lay ra vi tri va trang thai cua viec tim kiem vi tri
def get_api(source):

    responseSource= requests.get(f'http://ip-api.com/json/{source}').json()
    statusSource = {responseSource.get("status")}

    #Ham tra ve gia tri tags | 1: co tim thay geoIP, 0: Khong tim thay geoIP
    #Tra ve gia tri direction | 0: outbound, 1: inbound, 2: local

    #tra ve vi tri
    if statusSource != {'success'}:
        response = {
            "status": 'fail',
            'country': 'Vietnam',
            'countryCode': 'VN', 
            'region': 'HN',
            'regionName': 'Hanoi', 
            'city': 'Hanoi', 
            'zip': '100000', 
            'lat': 21.0313, 
            'lon': 105.8516, 
            'timezone': 'Asia/Bangkok',
            'tags': 1
        }
    elif statusSource == {'success'}:
        response = {
            'country': responseSource.get("country"),
            'countryCode': responseSource.get("countryCode"),
            'region': responseSource.get("region"),
            'regionName': responseSource.get("regionName"),
            'city': responseSource.get("city"),
            'zip': responseSource.get("zip"), 
            'lat': responseSource.get("lat"),
            'lon': responseSource.get("lon"),
            'timezone': responseSource.get("timezone"),
            'tags': 1
            }
    return response