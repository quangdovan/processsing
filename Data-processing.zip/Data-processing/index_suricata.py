import os, re
import time
import json
from datetime import datetime
from time import localtime,strftime,strptime
from datetime import date
from datetime import datetime, timezone
import regex
import pytz
import send_elastic

def timeUTC():
    tz = pytz.timezone('utc')
    berlin_now = datetime.now(tz)
    dt_string = berlin_now.strftime("%Y-%m-%dT%H:%M:%SZ")
    return dt_string

log_file_name = "/var/log/suricata/fast.log"

def read_file(last_size):
    log_file = open(log_file_name, 'r')

    #0,2 doc all file, để cung cấp vị trí làm việc cho hàm tell ở dưới
    seek = log_file.seek(0, 2)
    print('seek 0 2 = ', seek)
    
    #Cái này để xác định vị trí bắt đầu và kết thúc file (trong điểm làm việc)
    current_size = log_file.tell()
    #lines = []
    print("curren va last", current_size, last_size)
    if current_size > last_size:
        # co log moi
        #seek lay gia tri tai value cua last_size, mục đích để đọc từ text từ last_size đến current_size
        #Coi như đây là điểm file bắt đầu của file 
        log_file.seek(last_size)

        #Trừ đi để lấy vị trí text của log mới 
        block_size = current_size - last_size
        print('block size= ', block_size)

        #Đọc text với vị trí vừa trừ ở trên, code sẽ đọc bắt đầu từ [log_file.seek(last_size) -> block_size]
        new_log = log_file.read(block_size)
        print('new log  = ', new_log)

        #Loại bỏ các ký tự xuống dòng, nếu không lát đếu lặp từng dòng đc đâu
        lines = new_log.split("\n")

        #Đặt last_size = current_size để vòng lặp sau bắt đầu bằng vị trí current_size
        last_size = current_size
        # print("new log")
        print('lime day = ', lines)
    elif current_size < last_size:
        # file log duoc reset -> doc lai file tu dau
        last_size = 0
    else:
        # size giu nguyen -> khong co log moi
        pass
    log_file.close()
    return lines, last_size

def main_suricata():
    log_file = open(log_file_name, 'r')
    print(log_file_name)
    log_file.seek(0, 2)
    last_size = log_file.tell()
    log_file.close()
    while True:
        try:
            lines, last_size = read_file(last_size)
            if len(lines) > 0:
                count = 0
                for line in lines:
                    if len(line) >0:
                        count = count +1
                        timestamp = timeUTC()
                        data = eval(regex.suricata(line,timestamp))
                        if str(data['msg']) != 'No data':
                            print("khong rong")
                            send_elastic.send(data)
                        else:
                            print('bien rong')
                            pass
                print("count = ",count)
        except Exception as e:
            pass
        time.sleep(1)

#main_suricata()
