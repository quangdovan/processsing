import os, re
import time
import json
from datetime import datetime
from time import localtime,strftime,strptime
from datetime import date
from datetime import datetime, timezone
import pytz
import requests
def timeUTC():
    tz = pytz.timezone('utc')
    berlin_now = datetime.now(tz)
    dt_string = berlin_now.strftime("%Y-%m-%dT%H:%M:%SZ")
    return dt_string

log_file_name = "C:\\Users\\ADMIN\\OneDrive\\Máy tính\\quangdv\\waf.log"

def timeindex():
# datetime object containing current date and time
    now = datetime.now()
    print(now)
    # dd/mm/YY H:M:S
    nameindex = now.strftime("%Y.%m.%d")
    dt_string = now.strftime("%Y.%m.%d %H:%M:%S")
    print(dt_string)
    return nameindex, dt_string

def read_file(last_size):
    log_file = open(log_file_name, 'r')

    #0,2 doc all file, để cung cấp vị trí làm việc cho hàm tell ở dưới
    seek = log_file.seek(0, 2)
    print('seek 0 2 = ', seek)
    
    #Cái này để xác định vị trí bắt đầu và kết thúc file (trong điểm làm việc)
    current_size = log_file.tell()
    #lines = []
    print("curren va last", current_size, last_size)
    if current_size > last_size:
        # co log moi
        #seek lay gia tri tai value cua last_size, mục đích để đọc từ text từ last_size đến current_size
        #Coi như đây là điểm file bắt đầu của file 
        log_file.seek(last_size)

        #Trừ đi để lấy vị trí text của log mới 
        block_size = current_size - last_size
        print('block size= ', block_size)

        #Đọc text với vị trí vừa trừ ở trên, code sẽ đọc bắt đầu từ [log_file.seek(last_size) -> block_size]
        new_log = log_file.read(block_size)
        print('new log  = ', new_log)

        #Loại bỏ các ký tự xuống dòng, nếu không lát đếu lặp từng dòng đc đâu
        lines = new_log.split("\n")

        #Đặt last_size = current_size để vòng lặp sau bắt đầu bằng vị trí current_size
        last_size = current_size
        # print("new log")
        print('lime day = ', lines)
    elif current_size < last_size:
        # file log duoc reset -> doc lai file tu dau
        last_size = 0
    else:
        # size giu nguyen -> khong co log moi
        pass
    log_file.close()
    return lines, last_size




def regex(line,timestamp):
    try:
        time = re.findall(r'\[(.*?) ', line)[0]
        ip = re.findall(r'(\w+.\w+.\w+.\w+) - - ', line)[0]
        protocol = re.findall(r'.\"(.*?) \/', line)[0]
        msg = (r' \/ (.*?)\".\"', line)[0]
        code = (r'\d" (.*?) ', line)[0]
        detail = re.findall(r'" "(.*)', line)[0]
        properties = re.findall(r'" "(.*?)$', line)[0]
        url = re.findall(r'\d "(.*?)" "', line)[0]
        
        data = {
            "time":time,
            "ip":ip,
            "protocol":protocol,
            "code": code,
            "msg":msg,
            "detail":detail,
            "properties":properties,
            "url":url
            
        }
        return json.dumps(data)
    except Exception as e:
        raise e

def main_method():
    # khoi tao gia tri ve size ban dau cua file
    log_file = open(log_file_name, 'r')
    print(log_file_name)

    #lay vi tri dau va cuoi tep
    log_file.seek(0, 2)
    # print('a = ',a)
    #lay vi tri hien tai cua tep sau khi doc xong bang ham seek
    last_size = log_file.tell()
    print('lastsize = ',last_size)
    log_file.close()
    while True:
        try:
            #print('last size = ',last_size)
            #doc file voi vi tri là last_size, đặt biến lines = giá trị của lines hàm read_file
            #biến last_size = giá trị của last_size hàm read_file
            lines, last_size = read_file(last_size)
            print("line main = ", lines)
            print("lastsize main", last_size)

            #Nếu đội dài biến lines > 0 thì =>
            if len(lines) > 0:
                #lặp các dòng ở trong biến lines(biến lines là dữ liệu)
                count = 0
                for line in lines:
                    print('do dai cua line = ', len(line))
                    if len(line) >0:
                        count = count +1
                        timestamp = timeUTC()
                        print('time UTC = ', timestamp)
                        #timestamp = datetime.fromtimestamp(float(time.time())).strftime("%Y-%m-%dT%H:%M:%SZ")
                        data = regex(line,timestamp)
                        bta = eval(data)
                        print('data ==== ',type(data))
                        print(bta['msg'])
                        print(bta)
                        if str(bta['msg']) != '[]':
                            print("khong rong")
                            nameindex, dt_string1 = timeindex()
                            insert = f"http://localhost:9200/count_method-{nameindex}/_doc/?pretty"
                            requests.post(insert, json=bta)
                        else:
                            print('bien rong')
                            pass

                print("count = ",count)
        except Exception as e:
            pass
        time.sleep(1)
