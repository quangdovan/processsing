import getApi
import re
import json

def  check_null(list_item):
    default_list = ['No data']
    if len(list_item) > 0:
        return list_item
    else:
        return default_list
    
def waf(line,timestamp):
    try:
        time =  check_null(re.findall(r'(\w+ \w+ \d\d \d+:\d+:\d+)', line))[0]
        ARGS =  check_null(re.findall(r'ARGS:id: (.*?)"]', line))[0]
        code =  check_null(re.findall(r'ModSecurity:(.*?) \(', line))[0]
        rules =  check_null(re.findall(r'\/rules\/(.*?).conf', line))[0]
        src_ip =  check_null(re.findall(r'client (\d+.\d+.\d+.\d+)\]', line))[0]
        dest_ip =  check_null(re.findall(r'data "(\w+.\w+.\w+.\w+)', line))[0]
        msg =  check_null(re.findall(r'msg "(.*?)"', line))[0]
        domain =  check_null(re.findall(r'referer: (.*?)$', line))[0]
        hostname =  check_null(re.findall(r'hostname "(.*?)"', line))[0]
        uri =  check_null(re.findall(r'uri "(.*?)"', line))[0]
        kq_json = getApi.get_api(src_ip)
        data = {
            "time":time,
            "tag":'WAF',
            "code":code,
            "rules":rules,
            "src_ip":src_ip,
            "dst_ip":dest_ip,
            "msg":msg,
            "ARGS":ARGS,
            "domain":domain,
            "hostname":hostname,
            "uri":uri,
            "@timestamp": timestamp,
            "country_code": kq_json['countryCode'],
            "region_name": kq_json['region'],
            "timezone": kq_json['timezone'],
            "city_name": kq_json['city'],
            "lat": kq_json['lat'],
            "countryname": kq_json['country'],
            "lon": kq_json['lon']
        }
        return json.dumps(data)
    except:
        return "None"

def suricata(line,timestamp):
    try:
        # tag = ''
        # code = ''
        # rules = ''
        time = check_null(re.findall(r'^(.*?).\w+  ', line))[0]
        msg = check_null(re.findall(r'\b\] (.*) \[*\*', line))[0]
        src_ip = check_null(re.findall(r'} (.*):\w+ ->', line))[0]
        dest_ip = check_null(re.findall(r'-> (.*):', line))[0]
        # domain = ''
        # hostname = ''
        # uri = ''
        kq_json = getApi.get_api(src_ip)
        data = {
            "time":time,
            "tag": 'SURICATA',
            "code":'',
            "rules":'',
            "src_ip":src_ip,
            "dst_ip": dest_ip,
            "msg":msg,
            "ARGS":'',
            "domain":'',
            "hostname":'',
            "uri":'',
            "@timestamp": timestamp,
            "country_code": kq_json['countryCode'],
            "region_name": kq_json['region'],
            "timezone": kq_json['timezone'],
            "city_name": kq_json['city'],
            "lat": kq_json['lat'],
            "countryname": kq_json['country'],
            "lon": kq_json['lon']
        }
        return json.dumps(data)
    except:
        return "None"
