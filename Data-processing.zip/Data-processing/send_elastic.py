import time
from datetime import datetime
import requests
import json

def timeindex():
    now = datetime.now()
    print(now)
    # dd/mm/YY H:M:S
    nameindex = now.strftime("%Y.%m.%d")
    return nameindex

def send(data):
    nameindex = timeindex()
    insert = f"http://192.168.109.149:9200/test-{nameindex}/_doc/?pretty"
    requests.post(insert, json=data)
    print("Send complete")
