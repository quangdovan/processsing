from multiprocessing import Process
import index_waf
import index_suricata
if __name__ == '__main__':
  p1 = Process(target=index_suricata.main_suricata)
  p1.start()
  p2 = Process(target=index_waf.main_waf)
  p2.start()
  p1.join()
  p2.join()